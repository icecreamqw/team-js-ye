


import dezero.functions as F
import dezero.layers as L
from dezero import Model
import numpy as np

class LSTMLinearModel(Model):
    def __init__(self, hidden_size=100, out_size=3):
        super().__init__()
        self.lstm = L.LSTM(hidden_size)
        self.fc = L.Linear(out_size)

    def reset_state(self):
        self.lstm.reset_state()

    def __call__(self, xs):
        hs = []
        for x_t in xs.transpose(1, 0, 2):  # (seq_len, batch, features)
            h = self.lstm(x_t)
            hs.append(h)
        hs = F.stack(hs, axis=0)  # (seq_len, batch, hidden)
        hs = F.transpose(hs, (1, 0, 2))  # (batch, seq_len, hidden)
        hs_mean = F.mean(hs, axis=1)
        out = self.fc(hs_mean)
        return out, None


class AttentionLinearModel(Model):
    def __init__(self, input_size=3, hidden_size=100, out_size=3):
        super().__init__()
        self.attn_fc = L.Linear(1)
        self.fc = L.Linear(out_size)

    def __call__(self, xs):
        B, T, D = xs.shape
        xs_2d = xs.reshape(B * T, D)
        e = self.attn_fc(xs_2d)  # (B*T, 1)
        e = e.reshape(B, T)
        e_np = np.exp(e.data - np.max(e.data, axis=1, keepdims=True))
        alpha = e_np / np.sum(e_np, axis=1, keepdims=True)
        alpha = alpha[:, :, None]  # (B, T, 1)
        alpha = F.as_variable(alpha)
        context = (xs * alpha).sum(axis=1)  # (B, D)
        out = self.fc(context)
        return out, alpha


class SigmoidLinearModel(Model):
    def __init__(self, hidden_size=100, out_size=3):
        super().__init__()
        self.fc1 = L.Linear(hidden_size)
        self.fc2 = L.Linear(out_size)

    def __call__(self, xs):
        hs = F.sigmoid(self.fc1(xs))  # (B, T, hidden)
        hs_mean = F.mean(hs, axis=1)  # (B, hidden)
        out = self.fc2(hs_mean)  # (B, out)
        return out, None


class MLPModel(Model):
    def __init__(self, hidden_size=100, out_size=3):
        super().__init__()
        self.fc1 = L.Linear(hidden_size)
        self.fc2 = L.Linear(hidden_size)
        self.fc3 = L.Linear(out_size)

    def __call__(self, xs):
        hs = F.relu(self.fc1(xs))
        hs = F.relu(self.fc2(hs))
        hs_mean = F.mean(hs, axis=1)
        out = self.fc3(hs_mean)
        return out, None


def get_model(name='lstm', **kwargs):
    if name == 'lstm':
        return LSTMLinearModel(**kwargs)
    elif name == 'attention':
        return AttentionLinearModel(**kwargs)
    elif name == 'sigmoid':
        return SigmoidLinearModel(**kwargs)
    elif name == 'mlp':
        return MLPModel(**kwargs)
    else:
        raise ValueError(f'Unknown model name: {name}')